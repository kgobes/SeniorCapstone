### Steps to reproduce

### Expected behavior
Tell us what should happen

### Actual behavior
Tell us what happens instead

### Your System configuration
- Python version: 
- Pydub version: 
- ffmpeg or avlib?: 
- ffmpeg/avlib version: 

### Is there an audio file you can include to help us reproduce?
You can include the audio file in this issue - just put it in a zip file and drag/drop the zip file into the github issue.

